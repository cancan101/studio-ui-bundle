
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/906007ce71b8-sdk/static/js/remoteEntry.js'
    