
      window.StudioUIBundleRemoteUrl = '/bundles/pimcorestudioui/build/cfb97de02d9d-sdk/static/js/remoteEntry.js'
    